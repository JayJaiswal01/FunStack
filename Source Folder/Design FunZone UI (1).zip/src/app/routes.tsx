import { createBrowserRouter } from "react-router";
import { Dashboard } from "./pages/Dashboard";
import { NumberGuessing } from "./pages/NumberGuessing";
import { SpinWheel } from "./pages/SpinWheel";
import { DiceBattle } from "./pages/DiceBattle";
import { QuickQuiz } from "./pages/QuickQuiz";
import { TaskGenerator } from "./pages/TaskGenerator";
import { GameModeSelection } from "./pages/GameModeSelection";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Dashboard,
  },
  {
    path: "/number-guessing",
    Component: GameModeSelection,
  },
  {
    path: "/number-guessing/:mode",
    Component: NumberGuessing,
  },
  {
    path: "/spin-wheel",
    Component: SpinWheel,
  },
  {
    path: "/dice-battle",
    Component: DiceBattle,
  },
  {
    path: "/quick-quiz",
    Component: QuickQuiz,
  },
  {
    path: "/task-generator",
    Component: TaskGenerator,
  },
]);
